package com.challengefriends

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val gold = Color.rgb(212, 175, 55)
    private val dark = Color.rgb(9, 9, 9)
    private val panel = Color.rgb(30, 30, 30)
    private val ui = Handler(Looper.getMainLooper())
    private val roundLock = Any()
    private var root: LinearLayout? = null
    private var playerName = "لاعب"
    private var isHost = false
    private var server: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var clientWriter: PrintWriter? = null
    private val clients = LinkedHashMap<String, Peer>()
    private val scores = LinkedHashMap<String, Int>()
    private val names = LinkedHashMap<String, String>()
    private var currentAnswer = ""
    private var currentGame = ""
    private var roundDone = false
    private var roundNumber = 0
    private var showingClientResult = false
    private var inputAnswer: EditText? = null
    private var statusText: TextView? = null
    private var roomInfo = ""

    private data class Peer(val socket: Socket, val writer: PrintWriter, val name: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        home()
    }

    private fun screen(title: String, subtitle: String = "") {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            setPadding(22, 20, 22, 24)
            setBackgroundColor(dark)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        text(title, 27, gold, true)
        if (subtitle.isNotBlank()) text(subtitle, 14, Color.LTGRAY)
    }

    private fun text(value: String, size: Int = 16, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val v = TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(8, 9, 8, 9)
            if (bold) setTypeface(null, Typeface.BOLD)
        }
        root?.addView(v, LinearLayout.LayoutParams(-1, -2))
        return v
    }

    private fun button(value: String, action: () -> Unit) {
        root?.addView(Button(this).apply {
            text = value
            textSize = 16f
            setTextColor(Color.BLACK)
            setBackgroundColor(gold)
            isAllCaps = false
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 6, 0, 6) })
    }

    private fun field(hint: String): EditText {
        val e = EditText(this).apply {
            this.hint = hint
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            setSingleLine(true)
            setPadding(14, 8, 14, 8)
            setBackgroundColor(panel)
        }
        root?.addView(e, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 7, 0, 7) })
        return e
    }

    private fun home() {
        screen("✦ تحدّي الأصدقاء ✦", "ثلاثة تحديات • منافسة مباشرة • بدون إنترنت")
        val name = field("اكتب اسمك")
        button("إنشاء غرفة (المضيف)") {
            playerName = name.text.toString().trim().ifBlank { "المضيف" }
            createRoom()
        }
        button("الانضمام إلى غرفة") {
            playerName = name.text.toString().trim().ifBlank { "لاعب" }
            joinScreen()
        }
        button("تجربة فردية") {
            playerName = name.text.toString().trim().ifBlank { "لاعب" }
            isHost = false
            gameMenu()
        }
        text("ملاحظة: اتصلوا جميعًا بنقطة اتصال المضيف قبل إنشاء/الانضمام إلى الغرفة.", 13, Color.LTGRAY)
    }

    private fun createRoom() {
        isHost = true
        scores.clear(); names.clear(); clients.clear()
        scores["HOST"] = 0; names["HOST"] = playerName
        thread {
            try {
                server = ServerSocket(45454)
                roomInfo = "عنوان IP: ${localIp()}\nرقم المنفذ: 45454"
                ui.post { lobby() }
                while (!server!!.isClosed) {
                    val s = server!!.accept()
                    s.tcpNoDelay = true
                    thread { handlePeer(s) }
                }
            } catch (e: Exception) {
                if (!isFinishing) ui.post { toast("تعذر تشغيل الغرفة: ${e.message}") }
            }
        }
    }

    private fun handlePeer(s: Socket) {
        val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
        val writer = PrintWriter(s.getOutputStream(), true)
        val first = reader.readLine() ?: run { s.close(); return }
        val join = try { JSONObject(first) } catch (_: Exception) { JSONObject() }
        val name = join.optString("name", "لاعب").take(20).ifBlank { "لاعب" }
        val id = UUID.randomUUID().toString()
        synchronized(clients) {
            clients[id] = Peer(s, writer, name)
            names[id] = name
            scores[id] = 0
        }
        broadcastState()
        try {
            while (true) {
                val line = reader.readLine() ?: break
                val msg = try { JSONObject(line) } catch (_: Exception) { continue }
                if (msg.optString("type") == "SUBMIT") processSubmission(id, msg.optString("answer"))
            }
        } catch (_: Exception) {
        } finally {
            synchronized(clients) { clients.remove(id); names.remove(id); scores.remove(id) }
            try { s.close() } catch (_: Exception) {}
            broadcastState()
        }
    }

    private fun joinScreen() {
        screen("الانضمام إلى غرفة", "اكتب عنوان IP الظاهر على هاتف المضيف")
        val ip = field("مثال: 192.168.43.1")
        button("اتصال بالغرفة") {
            val address = ip.text.toString().trim()
            if (address.isBlank()) { toast("اكتب عنوان IP أولًا"); return@button }
            thread {
                try {
                    val s = Socket(address, 45454)
                    s.tcpNoDelay = true
                    clientSocket = s
                    val out = PrintWriter(s.getOutputStream(), true)
                    clientWriter = out
                    out.println(JSONObject().put("type", "JOIN").put("name", playerName).toString())
                    val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                    while (true) {
                        val line = reader.readLine() ?: break
                        val msg = JSONObject(line)
                        ui.post { handleServerMessage(msg) }
                    }
                    ui.post { toast("انقطع الاتصال بالمضيف") }
                } catch (e: Exception) {
                    ui.post { toast("فشل الاتصال: تأكد من الشبكة وعنوان IP والمنفذ 45454") }
                }
            }
        }
        button("رجوع") { home() }
    }

    private fun handleServerMessage(msg: JSONObject) {
        when (msg.optString("type")) {
            "STATE" -> {
                val arr = msg.optJSONArray("players") ?: JSONArray()
                val lines = (0 until arr.length()).map { i ->
                    val p = arr.getJSONObject(i)
                    "${p.optString("name")}: ${p.optInt("score")} نقطة"
                }
                if (!isHost && !showingClientResult) lobbyClient(lines)
            }
            "GAME" -> { showingClientResult = false; showRound(msg) }
            "RESULT" -> { showingClientResult = true; showResult(msg) }
            "WRONG" -> statusText?.text = msg.optString("message", "إجابة غير صحيحة، حاول مجددًا")
        }
    }

    private fun lobby() {
        screen("غرفة الانتظار", roomInfo)
        text("أرسل عنوان IP لأصدقائك. يجب أن يكونوا على نقطة اتصالك.", 14, Color.WHITE)
        text("اللاعبون المتصلون", 18, gold, true)
        val playerRows = synchronized(scores) { names.keys.map { id -> "${names[id] ?: "لاعب"} — ${scores[id] ?: 0} نقطة" } }
        playerRows.forEach { text(it, 15, Color.WHITE) }
        button("تحديث اللاعبين") { lobby() }
        button("ابدأ تحدي ترتيب الأرقام") { startRound("numbers") }
        button("ابدأ تحدي ترتيب الكلمات") { startRound("word") }
        button("ابدأ تحدي الذاكرة") { startRound("memory") }
        button("عرض النتائج") { showScoreboard() }
        button("إغلاق الغرفة") { closeNetwork(); home() }
    }

    private fun lobbyClient(playerLines: List<String>) {
        screen("أنت داخل الغرفة", "متصل بالمضيف")
        text("اللاعبون والنقاط", 18, gold, true)
        playerLines.forEach { text(it, 15, Color.WHITE) }
        text("انتظر المضيف ليبدأ التحدي.", 14, Color.LTGRAY)
        button("تحديث") { sendToHost(JSONObject().put("type", "PING")) }
    }

    private fun startRound(game: String) {
        if (!isHost) return
        roundNumber++
        roundDone = false
        currentGame = game
        val msg = JSONObject().put("type", "GAME").put("round", roundNumber).put("game", game)
        when (game) {
            "numbers" -> {
                val values = (1..6).shuffled()
                currentAnswer = values.sorted().joinToString(",")
                msg.put("prompt", "رتّب هذه الأرقام تصاعديًا: ${values.joinToString(" - ")}")
                    .put("hint", "اكتب الأرقام مفصولة بفواصل، مثال: 1,2,3")
            }
            "word" -> {
                val word = listOf("مدرسة", "حديقة", "هاتف", "صداقة", "مفتاح", "سيارة", "نجمة").random()
                currentAnswer = word
                msg.put("prompt", "رتّب الحروف لتكوين كلمة: ${word.toList().shuffled().joinToString(" ")}")
                    .put("hint", "اكتب الكلمة كاملة")
            }
            else -> {
                val sequence = (1..5).map { (1..9).random() }.joinToString("")
                currentAnswer = sequence
                msg.put("prompt", "احفظ تسلسل الأرقام: $sequence")
                    .put("hint", "سيختفي التسلسل بعد ثوانٍ؛ اكتبه من ذاكرتك")
            }
        }
        broadcast(msg)
        showRound(msg)
    }

    private fun showRound(msg: JSONObject) {
        currentGame = msg.optString("game")
        screen("التحدي رقم ${msg.optInt("round")}", gameTitle(currentGame))
        val prompt = text(msg.optString("prompt"), 21, gold, true)
        text(msg.optString("hint"), 14, Color.LTGRAY)
        if (currentGame == "memory") {
            ui.postDelayed({ prompt.text = "اكتب تسلسل الأرقام الذي حفظته" }, 3500)
        }
        inputAnswer = field("اكتب إجابتك هنا")
        statusText = text("أرسل إجابتك. أول إجابة صحيحة تفوز بالجولة.", 14, Color.WHITE)
        button("إرسال الإجابة") {
            val answer = inputAnswer?.text?.toString()?.trim().orEmpty()
            if (answer.isBlank()) toast("اكتب إجابتك") else submit(answer)
        }
        button("عرض النتائج") { if (isHost) showScoreboard() }
    }

    private fun submit(answer: String) {
        if (isHost) processSubmission("HOST", answer) else sendToHost(JSONObject().put("type", "SUBMIT").put("answer", answer))
        statusText?.text = "تم إرسال إجابتك، انتظر النتيجة..."
    }

    private fun processSubmission(id: String, raw: String) {
        if (!isHost) return
        var wonBy: String? = null
        synchronized(roundLock) {
            if (roundDone) return
            if (normalize(raw) == normalize(currentAnswer)) {
                roundDone = true
                wonBy = synchronized(scores) {
                    val player = names[id] ?: playerName
                    scores[id] = (scores[id] ?: 0) + 100
                    player
                }
            }
        }
        if (wonBy != null) {
            val player = wonBy!!
            val result = JSONObject().put("type", "RESULT").put("winner", player)
                .put("message", "إجابة صحيحة! حصل $player على 100 نقطة")
            broadcast(result)
            showResult(result)
            broadcastState()
        } else if (id == "HOST") {
            statusText?.text = "إجابة غير صحيحة، حاول مرة أخرى"
        } else {
            synchronized(clients) { clients[id]?.writer?.println(JSONObject().put("type", "WRONG").put("message", "إجابة غير صحيحة").toString()) }
        }
    }

    private fun showResult(msg: JSONObject) {
        screen("نتيجة الجولة", "انتهى التحدي")
        text(msg.optString("message", "لم يتم تسجيل فائز"), 20, gold, true)
        if (isHost) {
            button("تحدٍ جديد: أرقام") { startRound("numbers") }
            button("تحدٍ جديد: كلمات") { startRound("word") }
            button("تحدٍ جديد: ذاكرة") { startRound("memory") }
            button("لوحة النتائج") { showScoreboard() }
        } else {
            text("انتظر المضيف لبدء الجولة التالية.", 14, Color.LTGRAY)
        }
    }

    private fun showScoreboard() {
        screen("لوحة النتائج", "ترتيب اللاعبين حسب النقاط")
        val rows = synchronized(scores) { scores.entries.sortedByDescending { it.value }.map { "${names[it.key] ?: "لاعب"} — ${it.value} نقطة" } }
        if (rows.isEmpty()) text("لا توجد نتائج بعد", 16, Color.WHITE)
        rows.forEachIndexed { i, row -> text("${i + 1}. $row", 17, if (i == 0) gold else Color.WHITE, i == 0) }
        button("العودة إلى الغرفة") { if (isHost) lobby() else lobbyClient(rows) }
    }

    private fun broadcastState() {
        if (!isHost) return
        val arr = JSONArray()
        synchronized(scores) {
            scores.forEach { (id, score) ->
                arr.put(JSONObject().put("name", names[id] ?: "لاعب").put("score", score))
            }
        }
        broadcast(JSONObject().put("type", "STATE").put("players", arr))
    }

    private fun broadcast(msg: JSONObject) {
        val line = msg.toString()
        synchronized(clients) { clients.values.toList().forEach { peer -> try { peer.writer.println(line) } catch (_: Exception) {} } }
    }

    private fun sendToHost(msg: JSONObject) {
        try { clientWriter?.println(msg.toString()) } catch (_: Exception) { toast("تعذر إرسال الإجابة") }
    }

    private fun normalize(s: String): String = s.trim().replace(" ", "").replace("،", ",").replace("ـ", "")
        .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا").lowercase()

    private fun gameTitle(game: String) = when (game) {
        "numbers" -> "ترتيب الأرقام"
        "word" -> "ترتيب الكلمات"
        else -> "تحدّي الذاكرة"
    }

    private fun localIp(): String {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) for (addr in Collections.list(intf.inetAddresses)) {
                if (!addr.isLoopbackAddress && addr is Inet4Address) {
                    val ip = addr.hostAddress ?: continue
                    if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) return ip
                }
            }
        } catch (_: Exception) {}
        return "لم يتم اكتشافه؛ افحص تفاصيل نقطة الاتصال"
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun closeNetwork() {
        try { server?.close() } catch (_: Exception) {}
        try { clientSocket?.close() } catch (_: Exception) {}
        synchronized(clients) { clients.values.forEach { try { it.socket.close() } catch (_: Exception) {} }; clients.clear() }
    }

    override fun onDestroy() {
        closeNetwork()
        super.onDestroy()
    }
}
